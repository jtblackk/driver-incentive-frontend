import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    #Selecting all sponsors of an org user entries
    query = "SELECT * FROM Users WHERE Organization='%s' and AccountType='Sponsor'" % event['Organization']
    
    s = dynamodb_client.execute_statement(Statement=query)
    
    UserList = []
    SponsorList = []
    
    
    for i in s['Items']:
        
        #Selecting all drivers under a certain sponsor
       query = "SELECT * FROM Sponsorships WHERE SponsorID='%s'" % i['Username']['S']
       data = dynamodb_client.execute_statement(Statement=query)
       UserList.append(i)
        
       
       
       for x in data['Items']:
          
           query = "SELECT * FROM Users WHERE Username='%s'" % x['DriverID']['S']
           d = dynamodb_client.execute_statement(Statement=query)
           combined_data =  {**x, **d['Items'][0]}
           UserList.append(combined_data)
           
           
    
    
   
   
    
    
    return {
        'statusCode': 200,
        'body': json.dumps(UserList)
        }