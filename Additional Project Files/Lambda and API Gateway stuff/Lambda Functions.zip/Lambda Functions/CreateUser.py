import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    

    user_name = event['Username']
    aws_client = boto3.client('cognito-idp', 
    region_name = "us-east-1"
    )
    response = aws_client.admin_create_user(
    UserPoolId = "us-east-1_FWuyNmWFi",
    Username = user_name, 
    DesiredDeliveryMediums = ['EMAIL']
    )
    
    
    
   
    
    
    return {
        'statusCode': 200,
        'body': "User Created!"
        }