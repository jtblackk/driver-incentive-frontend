import boto3
import json
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime
import requests

def lambda_handler(event, context):
	
	order_total = 0
	count = 0
	text = "Thank you for using our driver rewards program! Your order is as follows:\n\n"
	for i in event['products']:
		product_id = i 
		item_data = requests.get(f"https://open.api.ebay.com/shopping?appid=JeffBlac-DriverIn-PRD-4418204ca-4dac81da&version=833&callname=GetSingleItem&responseencoding=JSON&siteid=0&itemId={product_id}&IncludeSelector=Description")
		parsed_item_data = item_data.json()
		quantity = event['quantities'][count]
		price = parsed_item_data['Item']['ConvertedCurrentPrice']['Value']
		order_total += price * quantity
		text += parsed_item_data['Item']['Title'] + " $" + str(parsed_item_data['Item']['ConvertedCurrentPrice']['Value']) + " x " + str(quantity) + " = $" + str(quantity * price)
		text += "\n"
		count = count + 1
	text += "\nTotal: $" + str(order_total)
	
	
	requests.post(
        "https://api.mailgun.net/v3/sandbox14fffcbca4b3433ba095aedf002f4d81.mailgun.org/messages",
	     auth=("api", "7341a493dbcfdebc5f95c9817a8671ac-e49cc42c-6a1b4406"),
	     data={"from": "Checkout Confirmation <mailgun@sandbox14fffcbca4b3433ba095aedf002f4d81.mailgun.org>",
			"to": event['userEmail'],
			"subject": "Checkout Confirmation",
			"text": text})
