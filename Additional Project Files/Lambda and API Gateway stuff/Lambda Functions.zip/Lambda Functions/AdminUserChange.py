import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")

    EmailID = event['EmailID']
    IsSuspended = event['IsSuspended']
    AdminNotes = event['AdminNotes']

    app_query1 = "UPDATE UserDetails SET AdminNotes='%s' WHERE Email_id='%s'" % (AdminNotes,EmailID)
    app_query2 = "UPDATE UserDetails SET IsSuspended='%s' WHERE Email_id='%s'" % (IsSuspended,EmailID)
    dynamodb_client.execute_statement(Statement=app_query1)
    dynamodb_client.execute_statement(Statement=app_query2)

    return {
        'statusCode': 200,
        'body': json.dumps("Success")
    }

