import json
import boto3
from boto3.dynamodb.conditions import Key
import datetime

def lambda_handler(event, context):
    
    # dyanmodb setup
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    SponsorID = event['SponsorID']
    DriverID = event['DriverID']
    AppComments = event['AppComments']
    AppDecisionReason = event['AppDecisionReason']
    date = str(datetime.datetime.now())
    SponsorshipID = str(SponsorID) + " | " + str(DriverID) 
    
    
    # create new sponsorship entry
    query = F"INSERT INTO Sponsorships value {{'SponsorshipID' : '%s', 'AppComments': '%s', 'AppDecisionDate': '%s', 'AppDecisionReason': '%s', 'AppSubmissionDate': '%s', 'DriverID': '%s', 'PointDollarRatio': %f, 'Points': %d, 'SponsorID': '%s', 'Status': %d }}"  % (SponsorshipID, AppComments, date, AppDecisionReason, date, DriverID, 0.01 , 0 , SponsorID , 2)
    data = dynamodb_client.execute_statement(Statement=query)
  
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST'
        },
        'body': 'success'
        }