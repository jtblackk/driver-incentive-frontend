import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    table = "Sponsorships" 
    
    print(event)
    Username = event['Username']
    
    query = F"SELECT * FROM {table} WHERE SponsorID='%s'" % Username
    
    r = dynamodb_client.execute_statement(Statement=query)

    return {
        'statusCode': 200,
        'body': json.dumps(r)
    }

