import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    

    SponsorUsername = event['SponsorUsername']
    
    
    query = "SELECT * FROM Sponsorships" 
    data = dynamodb_client.execute_statement(Statement=query)
    t = []
    j = 0
    i = 0
    
    query = "SELECT * FROM Sponsorships WHERE SponsorID = '%s' " % SponsorUsername
    d = dynamodb_client.execute_statement(Statement=query)
    j = 0
    for _ in range(len(d['Items'])):
        driverID = d['Items'][j]['DriverID']['S']
        query = "SELECT * FROM Users WHERE Username = '%s' " % driverID
        x = dynamodb_client.execute_statement(Statement=query)
        query2 = "SELECT * FROM Sponsorships WHERE SponsorID = '%s' AND DriverID = '%s'" % (SponsorUsername, driverID)
        y = dynamodb_client.execute_statement(Statement=query2)
        z = {
            **x['Items'][0],
            **y['Items'][0]
        }
        t.append(z)
        j = j + 1
        print(x)
        print(y)
            
            
            
    
        
    return {
        'statusCode': 200,
        'body': json.dumps(t)
    }
