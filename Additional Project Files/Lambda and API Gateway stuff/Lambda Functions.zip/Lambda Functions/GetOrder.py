import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    
    
    
    if "SponsorID" not in event and "DriverID" not in event and "Organization" in event:
        query = "SELECT * FROM Orders WHERE Organization='%s'" % event['Organization']
        data = dynamodb_client.execute_statement(Statement=query)
    
    if "SponsorID" in event and "DriverID" not in event and "Organization" not in event:
        query = "SELECT * FROM Orders WHERE SponsorID='%s'" % event['SponsorID']
        data = dynamodb_client.execute_statement(Statement=query)
    
    if "SponsorID" in event and "DriverID" in event and "Organization" not in event:
        query = "SELECT * FROM Orders WHERE SponsorID='%s' AND DriverID='%s'" % (event['SponsorID'], event['DriverID'])
        data = dynamodb_client.execute_statement(Statement=query)
    
    
    if "SponsorID" not in event and "DriverID" in event and "Organization" not in event:
        query = "SELECT * FROM Orders WHERE DriverID='%s'" % event['DriverID']
        data = dynamodb_client.execute_statement(Statement=query)
    
    
    
    return {
        'statusCode': 200,
        'body': json.dumps(data)
    }
