import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    
    query = "SELECT * FROM Sponsorships WHERE SponsorID='%s'" % event['SponsorID']
    
    x = dynamodb_client.execute_statement(Statement=query)
    
    
    
    for i in range(len(x['Items'])):
        query = "UPDATE Sponsorships SET PointDollarRatio=%f WHERE SponsorshipID='%s'" % (float(event['PointDollarRatio']), x['Items'][i]['SponsorshipID']['S'])
        dynamodb_client.execute_statement(Statement=query)
    
    

    return {
        'statusCode': 200,
        'body': json.dumps('success"')
        }