import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")

    applicant_email = event['applicant_email']
    application_status = event['applicationStatus']
    sponsor_email = event['SponsorEmailID']
    decision = event['decision']
    decisionReason = event['decisionReason']
    d = datetime.datetime.now()
    
    app_query0 = "UPDATE Applications SET decision='%s' WHERE applicant_email='%s'" % (decision,applicant_email)
    app_query4 = "UPDATE Applications SET decisionReason='%s' WHERE applicant_email='%s'" % (decisionReason, applicant_email)
    app_query1 = "UPDATE UserDetails SET ApplicationStatus='%s' WHERE Email_id='%s'" % (application_status,applicant_email)
    app_query5 = "UPDATE Applications SET decisionDateTime='%s' WHERE applicant_email='%s'" % (d, applicant_email)
    if decision == 'accepted':
        app_query2 = "UPDATE UserDetails SET SponsorEmailID='%s' WHERE Email_id='%s'" % (sponsor_email,applicant_email)
        app_query3 = "UPDATE UserDetails SET TotalPoints=0 WHERE Email_id='%s'" % applicant_email
        app_query_status = "UPDATE UserDetails SET Status=1 WHERE Email_id='%s'" % applicant_email

    dynamodb_client.execute_statement(Statement=app_query0)
    dynamodb_client.execute_statement(Statement=app_query1)
    dynamodb_client.execute_statement(Statement=app_query4)
    dynamodb_client.execute_statement(Statement=app_query5)
    if decision == 'accepted':
        dynamodb_client.execute_statement(Statement=app_query2)
        dynamodb_client.execute_statement(Statement=app_query3)
    
    
    return {
        'statusCode': 200,
        'body': json.dumps("Success")
    }

