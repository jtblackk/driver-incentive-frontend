import json
import requests

def chunks(l, n):
    for i in range(0, len(l), n):
        yield l[i:i + n]


def lambda_handler(event, context):
    # build querystring for ebay api call based off of product IDs passed in.
    product_id_chunks = list(chunks(event['ProductIDs'], 20))
    
    parsed_item_data = []
    for chunk in product_id_chunks:
        product_ids_querystring = ""
        count = 0
        for product_id in chunk:
            product_ids_querystring = product_ids_querystring + f"&ItemID({count})=" + product_id
            count += 1
        
        item_data = requests.get(f"https://open.api.ebay.com/shopping?appid=JeffBlac-DriverIn-PRD-4418204ca-4dac81da&version=833&callname=GetMultipleItems&responseencoding=JSON&siteid=0{product_ids_querystring}&IncludeSelector=TextDescription,Details")
        parsed_item_data = [*parsed_item_data, *item_data.json()['Item']]
        
        
    # TODO implement
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET'
        },
        'body': json.dumps({'Item': parsed_item_data})
    }