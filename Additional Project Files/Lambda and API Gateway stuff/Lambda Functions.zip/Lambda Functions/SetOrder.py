import json
import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    # TODO implement
        
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    DriverID = str(event['DriverID'])
    time = str(event['timestamp'])
    OrderID = DriverID + time
 
 
    
    
    if "Cost" in event:
        
        query = "UPDATE Orders SET Cost=%f WHERE OrderID='%s'" % (event['Cost'],OrderID)
        dynamodb_client.execute_statement(Statement=query)
    
    if "PDR" in event:
        
        query = "UPDATE Orders SET CurrentPointDollarRatio=%f WHERE OrderID='%s'" % (event['PDR'],OrderID)
        dynamodb_client.execute_statement(Statement=query)
    
    if "NewOrgName" in event:
        
        query = "UPDATE Orders SET Organization='%s' WHERE OrderID='%s'" % (event['NewOrgName'],OrderID)
        dynamodb_client.execute_statement(Statement=query)
    
    if "ProductIDs" in event:
        
        query = F"UPDATE Orders SET ProductIDs={event['ProductIDs']} WHERE OrderID='%s'" % OrderID
        dynamodb_client.execute_statement(Statement=query)
    
    if "Cost" in event:
        
        query = "UPDATE Orders SET Cost=%f WHERE OrderID='%s'" % (event['Cost'],OrderID)
        dynamodb_client.execute_statement(Statement=query)
    
    
    if "Status" in event:
        
        query = "UPDATE Orders SET Status=%d WHERE OrderID='%s'" % (event['Status'],OrderID)
        dynamodb_client.execute_statement(Statement=query)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Success')
    }
