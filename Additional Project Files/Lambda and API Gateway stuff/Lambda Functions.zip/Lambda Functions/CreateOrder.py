import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime
import math

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    table = 'Orders'
    SponsorID = event['SponsorID']
    DriverID = event['DriverID']
    ProductIDs = event['ProductIDs']
    cost = float(event['Cost'])
    ShippingAddress = event['ShippingAddress']
    status = 1
    date = str(datetime.datetime.now())
    OrderID = str(DriverID) + str(date).replace(" ", "T") 
    SponsorshipID = str(SponsorID) + " | " + str(DriverID)
    
    # get the current pointtodollar ratio
    ratio = "SELECT * FROM Sponsorships WHERE DriverID='%s' and SponsorID='%s'" % (DriverID, SponsorID)
    data = dynamodb_client.execute_statement(Statement=ratio)
    PDRatio = float(data['Items'][0]['PointDollarRatio']['N'])
    TotalPoints = int(data['Items'][0]['Points']['N'])
    
    # get the sponsor's data
    sponsor_data_query =  "SELECT * FROM Users WHERE Username='%s'" % (SponsorID)
    sponsor_data = dynamodb_client.execute_statement(Statement=sponsor_data_query)
    Organization = sponsor_data['Items'][0]['Organization']['S']
   
    
    # create new order entry
    query = F"INSERT INTO Orders value {{'OrderID' : '%s', 'SponsorID': '%s', 'ProductIDs' : {ProductIDs}, 'Cost' : {cost}, 'Status' : {status}, 'OrderSubmitted' : '%s', 'CurrentPointDollarRatio' : {PDRatio} ,'DriverID' : '%s', 'Organization' : '%s', 'ShippingAddress' : '%s'  }}"  % (OrderID, SponsorID, date, DriverID, Organization, ShippingAddress)
    data = dynamodb_client.execute_statement(Statement=query)
    
    userPoints = TotalPoints - math.ceil((cost/PDRatio))
    difference = math.ceil((cost/PDRatio)) * -1
    
    ChangeID = str(DriverID) + "|" + str(SponsorID) + "|" + date
    pointLog_query = F"INSERT INTO PointChangeLogs value {{'ChangeID' : '%s','PointDifference' : {difference}, 'DriverID' : '%s', 'SponsorID' : '%s', 'TimeStamp' : '%s', 'PointChangeReason' : 'Catalog order', 'TotalPoints' : {userPoints} }}"  % (ChangeID, DriverID, SponsorID, date)
    dynamodb_client.execute_statement(Statement=pointLog_query)
    
    # update the driver's points
    query =  F"UPDATE Sponsorships SET Points=%d WHERE SponsorshipID='%s'" % ((TotalPoints - (cost/PDRatio)), SponsorshipID)
    data = dynamodb_client.execute_statement(Statement=query)
    
    return {
        'statusCode': 200,
        'body': 'success'
        }