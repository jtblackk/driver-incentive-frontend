import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    

    
    table = "Sponsorships" 
    SponsorID = event.get('SponsorID')
    DriverID = event.get('DriverID')
    
    time = datetime.datetime.now()
    ChangeID = DriverID + "|" + SponsorID + "|" + str(time)
    SponsorshipID = SponsorID + " | " + DriverID

   
    
    if "PointDollarRatio" in event:
        PointDollarRatio = event['PointDollarRatio']
        app_query = "UPDATE Sponsorships SET PointDollarRatio=%f WHERE SponsorshipID='%s'" % (PointDollarRatio,SponsorshipID)
        dynamodb_client.execute_statement(Statement=app_query)
    if "AppComments" in event:
        AppComments = event['AppComments']
        app_query2 = "UPDATE Sponsorships SET AppComments='%s' WHERE SponsorshipID='%s'" % (AppComments,SponsorshipID)
        dynamodb_client.execute_statement(Statement=app_query2)
    if "Points" in event and "Status" not in event:
        # get the driver's current point total
        ratio = "SELECT * FROM Sponsorships WHERE DriverID='%s' and SponsorID='%s'" % (DriverID, SponsorID)
        data = dynamodb_client.execute_statement(Statement=ratio)
        CurrentPointTotal = int(data['Items'][0]['Points']['N'])
    
        # calculate the change in points
        Points = int(event['Points'])
        difference = Points - CurrentPointTotal 
        
        # log the point change
        PointChangeReason = event['PointChangeReason']
        ChangeID = str(DriverID) + "|" + str(SponsorID) + "|" + str(time)
        pointLog_query = F"INSERT INTO PointChangeLogs value {{'ChangeID' : '%s','PointDifference' : {difference}, 'DriverID' : '%s', 'SponsorID' : '%s', 'TimeStamp' : '%s', 'PointChangeReason' : '%s' , 'TotalPoints' : {Points} }}"  % (ChangeID, DriverID, SponsorID, time, PointChangeReason)
        dynamodb_client.execute_statement(Statement=pointLog_query)
        
        # update driver's points
        app_query3 = "UPDATE Sponsorships SET Points=%d WHERE SponsorshipID='%s'" % (Points,SponsorshipID)
        dynamodb_client.execute_statement(Statement=app_query3)
    
        
    if "AppDecisionReason" in event:
        AppDecisionReason = event['AppDecisionReason']
        AppDecisionDate = datetime.datetime.now()
        app_query4 = "UPDATE Sponsorships SET AppDecisionReason='%s' WHERE SponsorshipID='%s'" % (AppDecisionReason,SponsorshipID)
        app_query_date = "UPDATE Sponsorships SET AppDecisionDate='%s' WHERE SponsorshipID='%s'" % (AppDecisionDate,SponsorshipID)
        dynamodb_client.execute_statement(Statement=app_query_date)
        dynamodb_client.execute_statement(Statement=app_query4)
    if "Status" in event:
        Status = int(event['Status'])
        app_query5 = "UPDATE Sponsorships SET Status=%d WHERE SponsorshipID='%s'" % (Status,SponsorshipID)
        dynamodb_client.execute_statement(Statement=app_query5)
    
    
    #############################

    
  
        
    #############################
    return {
        'statusCode': 200,
        'body': json.dumps("Success")
    }
