import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    table = "Users" 
    Username = event['Username']
    
    if "FirstName" in event:
        FirstName = event['FirstName']
        app_query = "UPDATE Users SET FirstName='%s' WHERE Username='%s'" % (FirstName,Username)
        dynamodb_client.execute_statement(Statement=app_query)
    if "LastName" in event:
        LastName = event['LastName']
        app_query2 = "UPDATE Users SET LastName='%s' WHERE Username='%s'" % (LastName,Username)
        dynamodb_client.execute_statement(Statement=app_query2)
    if "Bio" in event:
        Bio = event['Bio']
        app_query3 = "UPDATE Users SET Bio='%s' WHERE Username='%s'" % (Bio,Username)
        dynamodb_client.execute_statement(Statement=app_query3)
    if "AccountType" in event:
        AccountType = event['AccountType']
        app_query4 = "UPDATE Users SET AccountType='%s' WHERE Username='%s'" % (AccountType,Username)
        dynamodb_client.execute_statement(Statement=app_query4)
    if "AccountStatus" in event:
        AccountStatus = int(event['AccountStatus'])
        app_query5 = "UPDATE Users SET AccountStatus=%d WHERE Username='%s'" % (AccountStatus,Username)
        dynamodb_client.execute_statement(Statement=app_query5)
    if "Organization" in event:
        Organization = event['Organization']
        app_query6 = "UPDATE Users SET Organization='%s' WHERE Username='%s'" % (Organization,Username)
        dynamodb_client.execute_statement(Statement=app_query6)


    if "IsInitialSignup" in event:
        SignupDate = datetime.datetime.now()
        app_query6 = "UPDATE Users SET SignupDate='%s' WHERE Username='%s'" % (SignupDate,Username)
        dynamodb_client.execute_statement(Statement=app_query6)
        
    
    return {
        'statusCode': 200,
        'body': json.dumps("Success")
    }
