import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    
     # get all the Order entries
    query = "SELECT * FROM Orders WHERE Status < 3"
    orders = dynamodb_client.execute_statement(Statement=query)
    
    # update the org name in the order entries
    for order in orders['Items']:
        query = "UPDATE Orders SET Status=%d WHERE OrderID='%s'" % (int(order['Status']['N'])+1, order['OrderID']['S'])
        dynamodb_client.execute_statement(Statement=query)
        
        
    return {
        'statusCode': 200,
        'body': json.dumps('success"')
    }