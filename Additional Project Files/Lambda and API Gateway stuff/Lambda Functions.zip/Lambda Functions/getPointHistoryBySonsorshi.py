import json
import boto3
from boto3.dynamodb.conditions import Key
import datetime

def lambda_handler(event, context):
    # dynamodb stuff
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    SponsorID = event['SponsorID']
    DriverID = event['DriverID']
    SponsorshipID = str(SponsorID) + ' | ' + str(DriverID)
    
    # get driver's Sponsorships records
    table = "" 
    query1 = F"SELECT * FROM PointChangeLogs WHERE DriverID='%s' and SponsorID='%s'" % (DriverID, SponsorID)
    r1 = dynamodb_client.execute_statement(Statement=query1)
        
        
    return {
        'statusCode': 200,
        'body': r1['Items']
      
    }
