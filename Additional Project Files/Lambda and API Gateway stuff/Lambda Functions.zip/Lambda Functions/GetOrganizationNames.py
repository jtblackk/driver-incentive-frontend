import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    
    query = "SELECT Organization FROM Users WHERE AccountStatus=1 and AccountType='Sponsor'"
    x = dynamodb_client.execute_statement(Statement=query)
    
    unique_orgs = set()
    for element in x['Items']:
        unique_orgs.add(element['Organization']['S'])
        
    
    # print(unique_orgs)
    
    
    # for i in range(len(x['Items'])):
    #     query = "UPDATE Users SET Organization='%s' WHERE Username='%s'" % (event['NewOrgName'], x['Items'][i]['Username']['S'])
    #     dynamodb_client.execute_statement(Statement=query)
    
    
    # # get all the Order entries
    # query = "SELECT * FROM Orders WHERE Organization='%s'" % event['Org']
    # orders = dynamodb_client.execute_statement(Statement=query)
    # print(orders)
    
    # # # update the org name in the order entries
    # for order in orders['Items']:
    #     query = "UPDATE Orders SET Organization='%s' WHERE OrderID='%s'" % (event['NewOrgName'], order['OrderID']['S'])
    #     print(query)
    #     print('\n')
    #     dynamodb_client.execute_statement(Statement=query)
    

    return {
        'statusCode': 200,
        'body': list(unique_orgs)
        }