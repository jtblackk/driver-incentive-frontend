import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
#This function is used for submitting a drivers applicaiton

    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    table = "Sponsorships" 

    SponsorID = event['SponsorID']
    DriverID = event['DriverID']
    SponsorshipID = SponsorID + " | " + DriverID
    AppComments = event['AppComments']
    AppSubmissionDate = datetime.datetime.now()
    PointDollarRatio = 0
    Points = 0
    AppDecisionReason = "_"
    AppDecisionDate = "_"
    Status = 0
    
    query = F"INSERT INTO {table} value {{'SponsorshipID' : '%s', 'SponsorID': '%s' ,'DriverID' : '%s', 'AppComments': '%s', 'AppSubmissionDate': '%s', 'PointDollarRatio': %d,'Points': %d,'AppDecisionReason': '%s','AppDecisionDate': '%s','Status': %d}}" % (SponsorshipID, SponsorID, DriverID,AppComments, AppSubmissionDate,PointDollarRatio, Points, AppDecisionReason, AppDecisionDate, Status)
    dynamodb_client.execute_statement(Statement=query)
        
    
    return {
        'statusCode': 200,
        'body': json.dumps("Success")
    }
