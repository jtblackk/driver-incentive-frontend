import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    table = "Users" 
    table2 = "SponsorProducts"
    Username = event['Username']
    FirstName = event.get('FirstName')
    LastName = event.get('LastName')
    Bio = event.get('Bio')
    AccountType = event.get('AccountType')
    Organization = event.get('Organization')
    AccountStatus = event.get('AccountStatus')
    d = datetime.datetime.now()
    data = []
    
    print(Organization)
    
    # not setting up a sponsor account
    if not Organization:
        query = F"INSERT INTO {table} value {{'Username' : '%s', 'FirstName' : '%s', 'LastName': '%s', 'Bio': '%s','SignupDate': '%s', 'AccountStatus': %d,'AccountType': '%s'}}" % (Username, FirstName, LastName,Bio, d ,AccountStatus, AccountType)
        dynamodb_client.execute_statement(Statement=query)
    # setting up a sponsor account
    else:
        # attempt insertion
        try:
            query = F"INSERT INTO {table} value {{'Username' : '%s', 'FirstName' : '%s', 'LastName': '%s', 'Bio': '%s','SignupDate': '%s', 'AccountStatus': %d,'AccountType': '%s', 'Organization' : '%s', 'Sponsors' : []}}" % (Username, FirstName, LastName,Bio, d ,AccountStatus, AccountType, Organization)
            dynamodb_client.execute_statement(Statement=query)
        # if fail (i.e., there's already a User record for the sponsor, just update the organization
        except: 
            query = F"UPDATE Users SET Organization='{Organization}' WHERE Username='{Username}'"
            dynamodb_client.execute_statement(Statement=query)
        
        # create the sponsor's catalog
        create_catalog_query = F"INSERT INTO {table2} value {{'SponsorID' : '%s', 'ProductIDs' : []}}" % Username
        dynamodb_client.execute_statement(Statement=create_catalog_query)
    
 
    
    return {
        'statusCode': 200,
        'body': json.dumps("Success")
    }
