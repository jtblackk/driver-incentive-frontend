import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    # get driver's Sponsorships records
    table = "Sponsorships" 
    query1 = F"SELECT * FROM {table} WHERE DriverID='%s'" % event['DriverID']
    r1 = dynamodb_client.execute_statement(Statement=query1)
    
    # combine Sponsorships records w/ Sponsors' Users record
    sponsor_data = []
    for item in r1['Items']:
        query2 = F"SELECT * FROM Users WHERE Username='%s'" % item['SponsorID']['S']
        r2 = dynamodb_client.execute_statement(Statement=query2)
        try: 
            combined_data = {**item, **r2['Items'][0]}
            sponsor_data.append(combined_data)
        except:
            continue
        
        
    return {
        'statusCode': 200,
        'body': json.dumps({'Items':sponsor_data})
      
    }
