import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    
    query = "SELECT * FROM Sponsorships WHERE SponsorID='%s'" % event['Sponsor']
    data = dynamodb_client.execute_statement(Statement=query)
    
    for i in range(len(data['Items'])):
        SponsorID = event['Sponsor']
        DriverID = data['Items'][i]['DriverID']['S']
        SponsorshipID = SponsorID + DriverID
        query = "UPDATE Sponsorships SET PointDollarRatio='%s' WHERE SponsorshipID='%s'" % (event['NewPointDollarRatio'], SponsorshipID)
        dynamodb_client.execute_statement(Statement=query)
    
    

    return {
        'statusCode': 200,
        'body': json.dumps('success"')
        }