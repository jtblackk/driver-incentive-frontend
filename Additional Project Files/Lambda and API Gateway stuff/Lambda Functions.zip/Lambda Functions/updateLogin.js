var AWS = require('aws-sdk');



var docClient = new AWS.DynamoDB.DocumentClient();

var d = new Date();


exports.handler = (event, context, callback) => {
    
    var tableName = "UserDetails";
    
    var params = {
        TableName : tableName,
        Key:{
        "Email_id" : event.Email_id
        },
        UpdateExpression: "set LastLogin = :l",
        ExpressionAttributeValues : {
            
            ":l" : d.toISOString()
        }
    };
    docClient.update(params, function(err,data){
        
        if(err){
            callback(err)
            
        }
        else{
            
            callback(null,"Success!")
           
        }
        
        
    })
    
    
        console.log("Success: Everything executed correctly");
       callback(null,event)
       
};
