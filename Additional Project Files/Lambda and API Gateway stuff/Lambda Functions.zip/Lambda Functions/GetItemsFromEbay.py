import json
import requests


def lambda_handler(event, context):
   # get items from ebay search api
    appid = "JeffBlac-DriverIn-PRD-4418204ca-4dac81da"
    query = "CD"
    available_items_only = True
    max_entries = 100
    ebay_items = requests.get(f"https://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsByKeywords&SERVICE-VERSION=1.0.0&SECURITY-APPNAME={appid}&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&keywords={query}&entriesPerPage={max_entries}")
    parsed_json = ebay_items.json()
    
    ebay_item_list = []
    for item in parsed_json['findItemsByKeywordsResponse'][0]['searchResult'][0]['item']:
        isDuplicate = False
        for list_item in ebay_item_list:
            # print(list_item)
            if list_item['ItemID'] == item['itemId'][0]:
                isDuplicate = True
        if isDuplicate == False:
            ebay_item_list.append(
                {"ItemID": item['itemId'][0], "ItemName": item['title'][0], "Price": item['sellingStatus'][0]['currentPrice'][0]["__value__"], "PhotoURL": item['galleryURL'][0]})
        
        
    # TODO implement
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET'
        },
        'body': json.dumps(ebay_item_list)
    }
