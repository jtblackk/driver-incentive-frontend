import json
import boto3
from boto3.dynamodb.conditions import Key
import hashlib
import random
import datetime

def lambda_handler(event, context):
    
    # Creating the DynamoDB Client
    dynamodb_client = boto3.client('dynamodb', region_name="us-east-1")
    
    # Creating the DynamoDB Table Resource
    dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
    


    SponsorID = event['SponsorID']
  
   
    data = event['ProductIDs']
    # query = F"UPDATE SponsorProducts SET ProductIDs=LIST_APPEND(ProductIDs, {data}) WHERE SponsorID='%s'" % SponsorID
    query = F"UPDATE SponsorProducts SET ProductIDs={data} WHERE SponsorID='%s'" % SponsorID
    dynamodb_client.execute_statement(Statement=query)
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Success')
        }